/*
 //JavaScript
 // Name: Job Roberts
 //WPF 1410 Section 01
 // Date: 24 Oct 2014
 //Assignment:Functions_Personal.
 */
function makeAmazing(a, b){
    //Code here to run
    alert(a + b);
//invoking the code
}makeAmazing('Your computer is so smart' , ' and coding is fun.');

var name =prompt("Enter your name");
    console.log(name);

if (name === ""){
    //validate the user information
    name = prompt("You forgot to enter your name");
}
//alert the user of info
alert= prompt("Thank you for learning code "+ name +" say you are welcome");
console.log("Thank you for learning code "+ name +" say you are welcome");
var an1 = ["you are welcome", "thank you"];


if (an1)

   document.write("Look at this");
   console.log("Look at this");
