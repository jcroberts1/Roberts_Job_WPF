/*
 //JavaScript
 // Name: Job Roberts
 //WPF 1410 Section 01
 // Date: 24 Oct 2014
 //Assignment:Functions Wacky.
 */
var name =prompt("Please enter your name");
  console.log(name);

while(name===""){
    name = prompt("You forgot your name again");
}
document.write("Look at all those wacky dogs");
console.log("Look at all those wacky dogs");

function greet(name) {
    //code to run

    alert("Hello " + name + "");
}
alert =prompt("Hi "+name+" please enter an number");
console.log(alert);

//for loop
for (var i =20 ; i > 0; i--){
    console.log(i + 'dogs in the yard')


}
greet(name);


